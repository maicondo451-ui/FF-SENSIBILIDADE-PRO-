require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const crypto = require('crypto');
const { GoogleGenAI } = require('@google/genai');

const app = express();
const PORT = Number(process.env.PORT || 3000);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", 'data:'],
  connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"]
} }}));
app.use(express.json({ limit: '40kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(['/api/research', '/api/professionals', '/api/chat'], rateLimit({ windowMs: 60000, limit: 10, standardHeaders: true, legacyHeaders: false }));
const envValue = name => process.env[name] || '';
function adminOk(req) {
 const expected = envValue('ADMIN_PASSWORD'), provided = req.get('x-admin-password') || '';
 if (!expected || !provided) return false;
 const a = Buffer.from(expected), b = Buffer.from(provided);
 return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function writeEnv(name, value) {
 const fs = require('fs'), envPath = path.join(__dirname, '.env');
 const lines = fs.existsSync(envPath) ? fs.readFileSync(envPath, 'utf8').split(/\r?\n/) : [];
 const idx = lines.findIndex(line => line.startsWith(name + '='));
 const line = `${name}=${JSON.stringify(value)}`;
 if (idx >= 0) lines[idx] = line; else lines.push(line);
 fs.writeFileSync(envPath, lines.filter(Boolean).join('\n') + '\n', { mode: 0o600 });
 process.env[name] = value;
}
function geminiClient() {
 const key = envValue('GEMINI_API_KEY');
 if (!key) throw new Error('Configure GEMINI_API_KEY no .env do servidor para habilitar pesquisas.');
 return new GoogleGenAI({ apiKey: key });
}
function responseText(result) { return result.text || (result.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('\n') || 'A pesquisa não retornou texto.'; }
function responseSources(result) {
 const chunks = result.candidates?.[0]?.groundingMetadata?.groundingChunks || [], map = new Map();
 for (const chunk of chunks) if (chunk.web?.uri) map.set(chunk.web.uri, { url: chunk.web.uri, title: chunk.web.title || chunk.web.uri });
 return [...map.values()];
}
async function webResearch(message) {
 const ai = geminiClient();
 const result = await ai.models.generateContent({
  model: envValue('GEMINI_MODEL') || 'gemini-2.5-flash',
  contents: message,
  config: { systemInstruction: 'Você é um mecanismo de pesquisa do FF Sensitivity Pro. Pesquise na web e relate somente fatos sustentados por fontes. Não crie nem recomende valores de sensibilidade ou DPI. Separe dados confirmados, relatos e informações não encontradas. Responda em português brasileiro.', tools: [{ googleSearch: {} }] }
 });
 return { answer: responseText(result), sources: responseSources(result) };
}
function validateDevice(b) {
 const brand = String(b.brand || '').trim().slice(0,60), model = String(b.model || '').trim().slice(0,100);
 if (!brand || !model) throw new Error('Informe a marca e o modelo exato do aparelho.');
 return { brand, model, ram: Number(b.ram) || 0, dpi: Number(b.dpi) || 0,
  refresh: Number(b.refresh) || 60, performance: String(b.performance || 'não informado'),
  style: String(b.style || 'equilibrado'), aimPreference: String(b.aimPreference || 'equilibrada') };
}
// Algoritmo determinístico local: nenhuma IA participa da geração.
function calculateRecommendation(d) {
 let base = 154;
 if (d.ram && d.ram <= 3) base -= 10;
 else if (d.ram === 4) base -= 5;
 else if (d.ram >= 8) base += 2;
 if (d.refresh >= 120) base += 4; else if (d.refresh >= 90) base += 2;
 if (d.performance === 'quedas de FPS' || d.performance === 'aquecimento após jogar') base -= 9;
 if (d.performance === 'toque parece lento') base += 4;
 if (d.style === 'rush') base += 7;
 if (d.style === 'precisao') base -= 8;
 if (d.aimPreference === 'puxada curta para capa') base += 6;
 if (d.aimPreference === 'puxada longa para capa') base -= 3;
 if (d.aimPreference === 'controle e precisão') base -= 9;
 const clamp = n => Math.max(70, Math.min(200, Math.round(n)));
 const values = {
  'Geral': clamp(base),
  'Ponto vermelho': clamp(base - 5),
  'Mira 2x': clamp(base - 16),
  'Mira 4x': clamp(base - 29),
  'AWM': clamp(base - 49),
  'Olhadinha': clamp(base - 8)
 };
 // DPI é apresentado como faixa conservadora; sem resolução/tamanho/touch sampling confirmado,
 // não se finge precisão específica do modelo.
 let dpiCenter = d.dpi ? d.dpi : 400;
 if (d.performance === 'quedas de FPS' || d.performance === 'aquecimento após jogar') dpiCenter -= 10;
 if (d.style === 'precisao' || d.aimPreference === 'controle e precisão') dpiCenter -= 10;
 if (d.style === 'rush' || d.aimPreference === 'puxada curta para capa') dpiCenter += 10;
 dpiCenter = Math.max(360, Math.min(480, Math.round(dpiCenter / 10) * 10));
 return { values, dpi: { suggested: dpiCenter, range: `${Math.max(360,dpiCenter-20)}–${Math.min(480,dpiCenter+20)}`, note: 'Faixa experimental de densidade/escala Android, não uma medida de resposta do toque. Alterar DPI pode mudar o tamanho da interface; anote o valor original e volte atrás se algo ficar desconfortável.' },
  method: 'Cálculo determinístico local por regras. RAM tem peso limitado e não define sozinha os valores.',
  factors: { ram: d.ram || 'não informada', refreshHz: d.refresh, performance: d.performance, style: d.style, aimPreference: d.aimPreference },
  disclaimer: 'Ponto inicial para testes, não configuração oficial de profissional nem garantia de capa. O algoritmo não mede o toque físico, FPS ou latência do aparelho.' };
}
app.get('/api/admin/status', (req,res) => {
 if (!adminOk(req)) return res.status(401).json({error:'Senha administrativa incorreta ou ADMIN_PASSWORD não configurada.'});
 res.json({gemini:!!envValue('GEMINI_API_KEY'), search:true, model:envValue('GEMINI_MODEL') || 'gemini-2.5-flash', database:false});
});
app.post('/api/admin/config', (req,res) => {
 if (!adminOk(req)) return res.status(401).json({error:'Senha administrativa incorreta.'});
 const {geminiKey,geminiModel}=req.body||{};
 if (!geminiKey && !geminiModel) return res.status(400).json({error:'Informe uma configuração.'});
 if (geminiKey) { if(typeof geminiKey!=='string'||geminiKey.length<12||geminiKey.length>300)return res.status(400).json({error:'Chave Gemini inválida.'}); writeEnv('GEMINI_API_KEY',geminiKey.trim()); }
 if (geminiModel) { if(typeof geminiModel!=='string'||!/^[a-zA-Z0-9._-]{3,80}$/.test(geminiModel))return res.status(400).json({error:'Modelo inválido.'}); writeEnv('GEMINI_MODEL',geminiModel.trim()); }
 res.json({ok:true,message:'Integração de pesquisa salva no servidor.'});
});
app.post('/api/research', async(req,res)=>{
 try { const d=validateDevice(req.body||{});
  const q=`Pesquise especificações técnicas do celular ${d.brand} ${d.model}. Não confunda variantes. Procure fabricante, processador, RAM/armazenamento, tela, resolução, taxa de atualização e amostragem de toque somente quando houver fonte confiável. Também procure relatos públicos sobre Free Fire nesse modelo, deixando claro o que não foi confirmado. NÃO recomende nem invente sensibilidade ou DPI. Liste fontes e links.`;
  const r=await webResearch(q); res.json({...r,researchedAt:new Date().toISOString()});
 } catch(e){res.status(500).json({error:e.message||'Falha na pesquisa.'});}
});
app.post('/api/professionals', async(req,res)=>{
 try { const d=req.body?.brand&&req.body?.model?validateDevice(req.body):null;
  const q=`Pesquise sensibilidades divulgadas publicamente por jogadores profissionais/competitivos de Free Fire. ${d?`Priorize ${d.brand} ${d.model}, sem associar aparelho sem fonte.`:'Não limite por aparelho.'} Só apresente valores de mira, DPI, aparelho e jogador se uma fonte pública os confirmar. Inclua link e data da publicação quando disponíveis. Não invente registros e diga claramente se não encontrar dados confiáveis.`;
  const r=await webResearch(q); res.json({...r,researchedAt:new Date().toISOString()});
 } catch(e){res.status(500).json({error:e.message||'Falha na pesquisa profissional.'});}
});
app.post('/api/generate',(req,res)=>{
 try { const d=validateDevice(req.body||{}); res.json({ ...calculateRecommendation(d), generatedAt:new Date().toISOString(), device:d, classification:'cálculo determinístico do sistema — sem IA' }); }
 catch(e){res.status(400).json({error:e.message});}
});
app.post('/api/chat',async(req,res)=>{
 try { const q=String(req.body?.message||'').trim(); if(!q)return res.status(400).json({error:'Escreva uma pergunta.'});
  const r=await webResearch(`Responda esta dúvida geral sobre Free Fire, controles, HUD ou aparelho. Não crie uma sensibilidade personalizada; explique que o gerador do site usa algoritmo local. Pergunta: ${q}`);
  res.json(r);
 } catch(e){res.status(500).json({error:e.message||'Falha no assistente.'});}
});
app.get('/api/health',(req,res)=>res.json({ok:true,version:'5.1.0',generator:'deterministic',database:false,geminiResearchConfigured:!!envValue('GEMINI_API_KEY')}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const server=app.listen(PORT,()=>console.log(`FF Sensitivity Pro 5.1 rodando na porta ${PORT}`));
process.on('SIGTERM',()=>server.close(()=>process.exit(0)));
